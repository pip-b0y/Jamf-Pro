#!/bin/bash
message="VPP Migrate Helper: [Info]"
workingpath="$( cd "$(dirname "$0")" >/dev/null 2>&1 ; pwd -P )"
currentuser=$(/usr/bin/python -c 'from SystemConfiguration import SCDynamicStoreCopyConsoleUser; import sys; username = (SCDynamicStoreCopyConsoleUser(None, None, None) or [None])[0]; username = [username,""][username in [u"loginwindow", None, u""]]; sys.stdout.write(username + "\n");')


###MacOS Prefix
prefix_history=$(ls ${workingpath}/.cache | grep -hr "_macos" | sed 's/......$//')
echo ${prefix_history}

####iOSPrefix
prefix_history2=$(ls ${workingpath}/.cache | grep -hr "_iOS" | sed 's/....$//')
echo ${prefix_history2}


for filename in $workingpath/.cache/New_macos/*.xml ; do
	vpp_on_raw=$(cat $filename | xpath '//mac_application/vpp/assign_vpp_device_based_licenses' 2>&1 | awk -F '<assign_vpp_device_based_licenses>|</assign_vpp_device_based_licenses>' '{print $2}' | tr -d " \t\n\r")
	vpp_id_raw=$(cat $filename | xpath '//mac_application/general/id' 2>&1 | awk -F '<id>|</id>' '{print $2}' | tr -d " \t\n\r")
	vpp_token_raw=$(cat $filename | xpath '//mac_application/vpp/vpp_admin_account_id' 2>&1 | awk -F '<vpp_admin_account_id>|</vpp_admin_account_id>' '{print $2}' | tr -d " \t\n\r")
	echo "$filename $vpp_on_raw  $vpp_id_raw App ID  $vpp_token_raw token"
	echo "<mac_application><vpp><assign_vpp_device_based_licenses>${vpp_on_raw}</assign_vpp_device_based_licenses><vpp_admin_account_id>${vpp_token_raw}</vpp_admin_account_id></vpp></mac_application>"
	#echo "$vpp_token_raw"
done